<?php
	require_once "header.php";
?>
	sobre mi

<?php
	require_once "footer.php";
?>