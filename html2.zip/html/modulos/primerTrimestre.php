<?php
	require_once "header.php";
?>
<div id=altable align="center">		
		<table border="">
			<th colspan="2">1er trimestre</th>
			<tr>
				<td>a</td>
				<td id="derechaAl">b</td>
			</tr>
			<tr>
				<td>a</td>
				<td id="derechaAl">b</td>
			</tr>
			<tr>
				<td>a</td>
				<td id="derechaAl">b</td>
			</tr>
			<tr>
				<td>a</td>
				<td id="derechaAl">b</td>
			</tr>
			<tr>
				<td>a</td>
				<td id="derechaAl">b</td>
			</tr>
			<tr>
				<td>a</td>
				<td id="derechaAl">b</td>
			</tr>

		</table>
	</div>
<?php
	require_once "footer.php";
?>