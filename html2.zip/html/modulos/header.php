<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<LINK REL=StyleSheet HREF="style/style.css" TYPE="text/css" MEDIA=screen>
	<title>Ejercicios de PHP</title>
</head>
<body>
	
	<div id="tituloPHP"><h1>Ejercicios de PHP</h1></div>
	<!--
	<div align="center" >
		<table border="" id="tablaIndice">
			<tr>
				<td><a href="modulos/primerTrimestre.php">1er Trimestre</a></td>
				<td><a href="modulos/segundoTrimestre.php">2º Trimestre</a></td>
				<td><a href="modulos/about.php"> Sobre mi </a></td>
			</tr>
		</table>
	</div>
	-->
	