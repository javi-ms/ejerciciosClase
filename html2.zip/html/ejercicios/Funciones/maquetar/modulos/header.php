<html>
	<head>
		<title>Maquetación</title>
		<!--<link rel="stylesheet" type="text/css" href="css/style.css">-->
	</head>
	<body>
	<div id="template">
		<h1>Template</h1>
		<p>For your cats</p>
	</div>
	<div id="tablaCabecera">
		<table>
			<th><a href="">Home</a></th>
			<th><a href="">About</a></th>
			<th><a href="">Portfolio</a><th>
			<th><a href="">News</a><th>
			<th><a href="">Contact</a><th>
		</table>		
	</div>
	<div id="bannerDiv">
		<img src="img/banner1.jpg" id="banner1"/>
	</div>
	<div id="textoBanner">
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum autem ducimus recusandae maiores, nulla reiciendis nostrum odit rem odio molestias, sit inventore tenetur sed neque voluptates! Nulla tenetur facilis qui.</p>
	</div>
