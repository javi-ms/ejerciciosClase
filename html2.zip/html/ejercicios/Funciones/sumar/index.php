<!DOCTYPE html>
<html>
<head>
	<title>Sumar recursivamente</title>
</head>
<body>
	<form method="post" action="sumar.php">
		<label>Introduce Sumando</label>
		<input type="text" name="sumando">
		<input type="submit" name="enviar" value="Sumar">
	</form>
</body>
</html>