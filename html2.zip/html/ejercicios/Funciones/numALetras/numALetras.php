<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <form method="POST" action="convertir.php">
        
        <input type="text" name="cantidad">
        <input type="submit" name="enviar">
    </form>
</body>
</html>