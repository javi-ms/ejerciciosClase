<!DOCTYPE html>
<html>
<head>
	<title>Averiguar letra DNI</title>
</head>
<body>
	<form method="post" action="calcularNA.php">
		<label>Introduce Nombre</label>
		<input type="text" name="nombre">
		<br/>
		<label>Introduce Apellido</label>
		<input type="text" name="apellido">
		<br/>
		<input type="submit" name="enviar" value="Calcular">
		
	</form>
</body>
</html>