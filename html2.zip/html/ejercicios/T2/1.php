<?php
	
	for ($i=1; $i <= 10; $i++) { 
		echo $i.' ';
	}

	echo "<hr>";
	echo "<a href=\"vercodigo.php?src=1.php\">ver codigo</a><br/>";	
	echo "<a href=\"indexT2.php\">volver</a><br/>";	
?>