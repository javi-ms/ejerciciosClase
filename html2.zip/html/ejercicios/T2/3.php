<?php

	for ($i=1; $i <= 10 ; $i++) { 
		for ($j=1; $j <= 10 ; $j++) { 
			echo $i*$j.' ';
		}
		echo "<br/>";
	}
	echo "<hr>";
	echo "<a href=\"vercodigo.php?src=3.php\">ver codigo</a><br/>";	
	echo "<a href=\"indexT2.php\">volver</a><br/>";
?>