<!DOCTYPE html>
<html>
<head>
	<title>Ejercicios 1</title>
	<?php
	require_once "../modulos/header.php";
?>
</head>
<body>
	<div id=tablaUno align="center">		
		<table border="">
			<th colspan="2">1er trimestre</th>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">1</img></p></td>
					<td class="derechaAl"><a href="1.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">2</img></p></td>
					<td class="derechaAl"><a href="2.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">3</img></p></td>
					<td class="derechaAl"><a href="3.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">4</img></p></td>
					<td class="derechaAl"><a href="4.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">5</img></p></td>
					<td class="derechaAl"><a href="5.php">IR</a></td>
				</tr>
			</tr>
		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>
</body>
</html>
<?php
	require_once "../modulos/footer.php";
?>