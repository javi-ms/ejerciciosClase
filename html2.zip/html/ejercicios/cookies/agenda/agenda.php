cabecera
informacion
navegacion
acciones
contenido



agenda
alumnos
informacion: usted esta en el sistema como:
busqueda	+{
Listado de contactos
contact editar
contact editar
contact editar{
	opciones de edicion del contacto
	nombre
	tlf

	modificar, borrar, cancelar	
}
}
