<?php 
//	require_once buscaminas.php;
?>
<!DOCTYPE html>
<html>
<head>
	<title>BUSCAMINAS</title>
</head>
<body>
	<form method="post" action="buscaminas2.php">
		<input type="submit" name="enviar">
	</form>
</body>
</html>