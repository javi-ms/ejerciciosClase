
<!DOCTYPE html>
<html>
<head>
	<title>Prueba 1- Hola Mundo</title>
</head>
<body>
	<?php
		echo "Hola Mundo";
	?>
</body>
</html>