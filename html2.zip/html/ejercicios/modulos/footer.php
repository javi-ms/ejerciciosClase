<hr>
<?php
	require_once "../modulos/funciones.php";
	//interface_contador();
?>
	<p id="aliFoot">Realizado por Javier Mariscal Solís</p>
</body>
</html>