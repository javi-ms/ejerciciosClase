
<table>
	<tr>
		<td>a</td>
		<td>b</td>
		<td>c</td>
	</tr>
</table>