<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="calendario.php"	></form>

	<input type="text" name="mes"> 
	<input type="submit" name="enviar"> 
	
	<?php 
	echo "<hr>";
	echo "<a href=\"vercodigo.php?src=calendario.php\">ver codigo</a><br/>";	
	echo "<a href=\"indexArray.php\">volver</a><br/>";
	 ?>
</body>
</html>