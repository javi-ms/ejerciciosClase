<?php

	$meses = array( 'Enero', 'Febrero', 'Marzo', 'Abril',
					'Mayo', 'Junio', 'Julio', 'Agosto' ,
					'Septiembre', 'Octubre', 'Noviembre', 'Diciembre',
				);

	foreach ($meses as &$valor) {
  	 	echo $valor.' ';
	}

?>