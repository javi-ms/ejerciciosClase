<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="celdasSum.php">
		<label>¿Cuantos sumandos quieres?</label>
		<input type="text" name="num">
		<input type="submit" name="enviar">
	</form>
</body>
<?php 
echo "<hr>";
			echo "<a href=\"vercodigo.php?src=celdasSum.php\">ver codigo</a><br/>";	
			echo "<a href=\"indexFormulario.php\">volver</a><br/>";
 ?>
</html>