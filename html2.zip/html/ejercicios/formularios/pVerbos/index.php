<!DOCTYPE html>
<html>
<head>
	<title>PROYECTO VERBOS</title>
</head>
<body>
	<form method='post' action='verbos.php'>
		<label>Introduce un numero</label>
		<input type="text" name="cantidad">
		<input type="submit" name="enviar">
	</form>
</body>
</html>