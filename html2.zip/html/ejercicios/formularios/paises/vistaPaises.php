<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="paises.php">
		<input type="text" name="pais">
		<input type="submit" name="enviar">
	</form>
</body>
<?php 
		echo "<hr>";
		echo "<a href=\"vercodigo.php?src=paises.php\">ver codigo</a><br/>";	
		echo "<a href=\"../indexFormulario.php\">volver</a><br/>";
?>
</html>