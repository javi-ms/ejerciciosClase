<!DOCTYPE html>
<html>
<head>
	<title>Ejercicios 1</title>
	<?php
	require_once "../modulos/header.php";
?>
</head>
<body>
	<div id=tablaUno align="center">		
		<table border="">
		<tr>
			<th colspan="2">1er trimestre</th>
		</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Calendario</img></p></td>
				<td class="derechaAl"><a href="vistaCalendario.php">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Suma</img></p></td>
				<td class="derechaAl"><a href="vistaSuma.php">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Suma 2</img></p></td>
				<td class="derechaAl"><a href="sumar.php">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Registro</img></p></td>
				<td class="derechaAl"><a href="vistaRegistro.php">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Verbos</img></p></td>
				<td class="derechaAl"><a href="verbos.php">IR</a></td>
			</tr>
			<!--<tr>
				<td><p><img class="imgText" src="img/php.jpg">Proyecto verbos</img></p></td>
				<td class="derechaAl"><a href="pVerbos/index.php">IR</a></td>
			</tr>-
			<tr>
				<td><p><img class="imgText" src="img/php.jpg"> </img></p></td>
				<td class="derechaAl"><a href="paises/vistaPaises.php">IR</a></td>
			</tr>-->
		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>

<?php
	require_once "../modulos/footer.php";
?>