
	<div id=tablaUno align="center">		
		<table border="">
			<th colspan="2">1er trimestre</th>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Errores del diseño web</img></p></td>
					<td class="derechaAl"><a href="https://elrincondejms.wordpress.com/2016/09/21/los-10-errores-del-diseno-grafico/">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Resumen de la lectura desarrollo ágil</img></p></td>
					<td class="derechaAl"><a href="">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">info.php</img></p></td>
					<td class="derechaAl"><a href="info.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">Hola Mundo</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/holaMundo'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">Ficha personal</img></p></td>
					<td class="derechaAl"><a href="fichaPersonal.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">Area del circulo</img></p></td>
					<td class="derechaAl"><a href="circulo.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">1</img></p></td>
					<td class="derechaAl"><a href="1.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">2</img></p></td>
					<td class="derechaAl"><a href="2.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">3</img></p></td>
					<td class="derechaAl"><a href="3.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">4</img></p></td>
					<td class="derechaAl"><a href="4.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">5</img></p></td>
					<td class="derechaAl"><a href="5.php">IR</a></td>
				</tr>
		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>
