
<!DOCTYPE html>
<html>
<head>
	<title>Prueba 2- Ficha personal</title>
</head>
<body>

	<?php
		echo "Nombre: ";
		echo "Javier Mariscal Solís </br>";
		echo "Edad: ";
		echo "26 años </br>";
		echo "Localidad: ";
		echo "El Carpio(Córdoba) </br>";
		echo "Estudió en: ";
		echo "IES Los Remedios e IES Gran Capitan </br>	";
		echo "Carnet de conducir: ";
		echo "Si, B </br>";
		echo "<hr>";
		echo "<a href=\"vercodigo.php?src=fichaPersonal.php\">ver codigo</a><br/>";	
		echo "<a href=\"indexT1.php\">volver</a><br/>";	
	?>
</body>
</html>