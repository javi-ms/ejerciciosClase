<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="../../css/estilos.css" media="screen" />
		<title>Problema</title>
	</head>
<body>
	<form action="60_varsesion-2.php" method="post">
		Ingrese nombre de usuario:
			<input type="text" name="campousuario"><br>
			Ingrese clave:
			<input type="password" name="campoclave"><br>
			<input type="submit" value="confirmar">
		</form>
	</body>
</html>