<?php
	setcookie("usuario","javier",0);
?>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="../../css/estilos.css" media="screen" />
		<title>Problema</title>
	</head>
	<body>
		Cookie de sesión creada.<br>
		<a href="59_alumnos17.php">Retornar a la página anterior.</a>
	</body>
</html>