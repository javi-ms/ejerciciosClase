<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../css/estilos.css" media="screen" />
<title>Problema</title>
</head>
	<body>
		<?php
			require_once("ejercicio61.2.php");
			cabeceraPagina("Titulo principal de la página");
			echo "<br><br><center>Este es el cuerpo de la página<br><br></center>";
			piePagina("Pie de la página");
		?>
	</body>
</html>