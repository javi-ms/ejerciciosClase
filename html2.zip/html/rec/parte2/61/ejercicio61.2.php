<?php
function cabeceraPagina($tit)
{
echo "<table width=\"100%\"><tr><td bgcolor=\"#ffff00\"
align=\"center\">$tit</td></tr></table>";
}
function piePagina($tit)
{
echo "<table width=\"50%\" align=\"center\"><tr><td
bgcolor=\"#cccccc\">$tit</td></tr></table>";
}
?>