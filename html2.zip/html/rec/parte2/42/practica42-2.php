<<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../css/estilos.css" media="screen" />
	<title></title>
</head>
<body>
	<?php
		if (isset($_POST['enviar'])) {
			echo "holla";
		}
	?>
</body>
</html>