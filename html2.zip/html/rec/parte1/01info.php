<html> 
	<head> 
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/estilos.css" media="screen" />
		<title>PHP-Info</title> 
	</head> 
	<body> 
		<?php 
		phpinfo(); 
		?> 
	</body> 
</html> 