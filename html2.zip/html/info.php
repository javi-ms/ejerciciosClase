<?php 
phpinfo();
//echo "hola";

?>
