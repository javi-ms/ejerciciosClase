<?php
		/**
		 *ejercicios basicos de bucles
		 *@Autor:Javier Mariscal Solís
		 *@2ºDAW IES GRAN CAPITAN
		*/
		/*
		sumar los tres primeros numeros pares 
		dado un año indicar si es bisiesto
		dada un mes indicar el numero de dias
		*/

 	  
 	    
 	       /*for ($i=primerNUm; $i < 5; $i++) { 
 	       	/*$numpar=$i%2;
 	       	echo $numpar;
 	       }
 	       */


			for($i=2; $i<6; $i++){

					echo "$i";
			}

    	  
 		       
 		      		         
 	  											
		/**
		*Se utiliza para ver el codigo de la pagina actual
		*/
		/*																																																																																																																																																																																																																																																																																																																																																																																																																																																																																											echo "<br/><a href=\"vercodigo.php?src=circulo.php\">ver codigo</a>"	
		/*almacenar dos variables dibujar un calendario en formato calendario*/
	?>