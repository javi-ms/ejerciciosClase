<?php
	include("includes/funciones.php");
	require_once "includes/header.php";
	registrarPedido();
?>
<?php
	require_once "includes/footer.php";
?>