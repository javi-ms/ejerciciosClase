<?php
//llamada a la conexion con la BBDD
//require_once "includes/ModelEmpresas.php";
//$modelEmpresas =  new ModelEmpresas(); 
?>
<!DOCTYPE html>
<html>
<head>


	<!--
	el index sera a base de require-once
	MODULARIZAR: CABECERA
	pagina 

MIRAR INFORMACION HTML5
	-->
		<link rel="stylesheet" href="style/style.css"  type="text/css">
		<meta name="tipo_contenido"  content="text/html;" http-equiv="content-type" charset="utf-8">
		<title>WEB FCT</title>
	</head>
	<body>

	<h1 align="center">Carrito</h1>
	<hr/>