<?php
	echo "esto es una prueba";
?>