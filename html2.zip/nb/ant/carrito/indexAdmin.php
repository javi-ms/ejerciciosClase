<?php
require_once "includes/funciones";
if (isset($_POST['login'])) {
menu();
}
?>