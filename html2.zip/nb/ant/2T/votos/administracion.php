<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="1">
		<tr>
			<th>aqui ira el usuario</th>
			<th>aqui ira el tipo de usuario</th>
			<th>borrar, modificar</th>
		</tr>

	</table>
	<form>
		

	</form>
</body>
</html>