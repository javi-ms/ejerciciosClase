<?php

//creacion del array y sesion de array
/*
creacion de un array de sesiones en el que se puedan introducir otros usuarios, loguearte con ellos y borrarlos
*/
if (isset($_POST['loguear'])) {

}

?>