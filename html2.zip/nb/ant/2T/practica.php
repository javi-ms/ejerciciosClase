<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="stylesheet" href="style/style.css"  type="text/css">
	</head>
	<body>
		<h1>NOTAS</h1>
		
			<table border="1" id="indice">
				<tr>
					<td>
					<!--Aqui se vera los votos realizados y por que personas-->
						<a href="">home</a>
					</td>
					<!--Aqui se podran realizar las votaciones-->
					<td>
						<a href="">Votar</a>
					</td>
					<!--Aqui se podra añadir usuarios-->
					<td>
						<a href="">Administración</a>
					</td>
				</tr>
			</table>

			<form>
				<input type="text" maxlength="16" size="8" name="idLog">
				<input type="password" maxlength="16" size="5" name="idPass">
				<input type="submit" name="loguear">
			</form>

			<div>
				<table id="tNotas">
					<tr>
						<th>Usuario</th>
						<th>Nota</th>
					</tr>
					<tr>
						<td>a</td>
						<td>b</td>
					</tr>

				</table>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>
				<p>PRUEBA DOS</p>				

			</div>
			<p>AQUI DEBEN DE IR LAS PREGUNTAS ENCONTRADAS RELACIONADAS<br/>EN UNA LISTA</p>	



	</body>
</html>
<?php
/*
una pantalla con una cabecera
una navegacion{clientes, productos}
una informacion{}
cuerpo{
	
	ZONA de busqueda (por categorias)(lupa) 	boton +(para añadir uno nuevo){
							listado con registros(un enlace a un formulario de edición) 
	}

}
*/
?>