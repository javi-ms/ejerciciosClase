
<?php
/**
 *Creacion de una ficha en PHP
 *@Autor:Javier Mariscal Solís
 *@2ºDAW IES GRAN CAPITAN
*/
	echo '<img width="100" src="imagenes/foto.jpg">';
	echo '<p>Nombre: Javier </p>';
	echo '<p>Apellidos: Mariscal Solís</p>';
	echo '<p>Direccion: C/La Feria 35(El Carpio)</p>';
	echo '<p>Email: javimasogoku@gmail.com</p>';	
/**
*Se utiliza para ver el codigo de la pagina actual
*/
	echo "<a href=\"vercodigo.php?src=fichapersonal.php\">ver codigo</a>"	
?>


