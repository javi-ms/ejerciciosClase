<?php 

 session_start();
if(!isset($_SESSION['ok']))
$_SESSION['ok'];
/*
<?php
	if(!isset($_SESION['ok']))
	header(location: error.php)
	//ENVIA A PAGINA DE ERROR
?>

*/
?>

otro script

<?php
/*CIERRA _SESIO*/
	SS 
	inset
	SD
?>

