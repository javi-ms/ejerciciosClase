
<?php
/**
*meses del año
*
*
*/
	$mes=array("enero ", "febrero ","Marzo ", "Abril ","Mayo ","Junio ","Julio ","Agosto ","Septiembre ","Octubre ","Noviembre ","Diciembre");
		
	foreach($mes as $value){
		echo ($value);
	}
	
	
	echo "<br/><a href=\"vercodigo.php?src=mesesAnio.php\">ver codigo</a>"
?>