<?php

	$random_number = intval( "0" . rand(1,9));
	echo $random_number;
?>