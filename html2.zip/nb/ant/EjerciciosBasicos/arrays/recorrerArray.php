<?php
/**
*guardar en un array diez numeros y recorrerlos
*
*/
	$num=array(1,2,3,4,5,6,7,8,9,10);
	foreach($num as $value){
		echo ($value);
	}
	
	
	echo "<br/><a href=\"vercodigo.php?src=recorrerArray.php\">ver codigo</a>"
?>