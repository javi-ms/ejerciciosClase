<html>
<body>
	<form method="post" action="prueba2.php"> 
		<!--
	  <p> 
	  <input type="checkbox" name="checkbox[]" value="opcion 1">  
	  opcion 1<br> 
	  <input type="checkbox" name="checkbox[]" value="opcion 2">  
	  opcion 2<br> 
	  <input type="checkbox" name="checkbox[]" value="opcion 3">  
	  opcion 3 <br> 
	  <br> 
	-->
	</p> 

	<div>
				<p>Tipo B</p>
				<p>
					<input type="checkbox" name="checkbox[]" value="TB"/>B
					<input type="checkbox" name="checkbox[]" value="BTP"/>BTP
				</p>
				<p>Tipo C</p>
					<input type="checkbox" name="checkbox[]" value="C13"/>C1
					<input type="checkbox" name="checkbox[]" value="C14"/>C1+E
				<p>Tipo D</p>
					<input type="checkbox" name="checkbox[]" value="C15"/>D1
					<input type="checkbox" name="checkbox[]" value="C16"/>D1+E
			</div>

			
			  <input type="submit" name="Submit" value="Enviar"> 
	</form> 
	</body>
</html>