<?php
echo "<table>";
for ($i=1; $i <= 31 ; $i++) { 
	echo "<tr>";
	echo " <td>".$i."</td> ";
	echo "</tr>";

}
echo "</table>";
?>