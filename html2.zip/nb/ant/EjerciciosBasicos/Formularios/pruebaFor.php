<?php
	$miarray[0]=10;
$miarray[1]=5;
$miarray[2]=8;
$miarray[3]=2;
$miarray[4]=4;

$resultado=0;
Foreach ($miarray as $valor){
$resultado=$resultado+$valor;
}

echo $resultado; 

	
?>