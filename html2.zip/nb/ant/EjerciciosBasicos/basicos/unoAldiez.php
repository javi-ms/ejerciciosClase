<?php
/**
*Numeros del uno al diez
*
*/
	for ($i=1; $i <= 10; $i++) { 
		echo $i." ";
	}
	echo "<br/><a href=\"vercodigo.php?src=fecha.php\">ver codigo</a>"
?>