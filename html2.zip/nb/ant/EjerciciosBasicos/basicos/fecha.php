<?php
/**
*edad
*
*/
	$fechanac=1982;
	$fechaAct=2015;
	
	$edad= ($fechaAct-$fechanac);
	echo "Tiene: ".$edad. " Años";

	echo "<br/><a href=\"vercodigo.php?src=fecha.php\">ver codigo</a>"
?>