	<?php
		/**
		 *Imagen de una estacion segun fecha
		 *@Autor:Javier Mariscal Solís
		 *@2ºDAW IES GRAN CAPITAN
		*/
		
		$dia=date('d');
		$mes=date('m');
		print = "Hoy es $dia - $mes";
		/**
		*Se utiliza para ver el codigo de la pagina actual
		*/
		echo "<br/><a href=\"vercodigo.php?src=circulo.php\">ver codigo</a>"	
	
	?>



