<div id=tablaUno align="center">		
		<table border="">
			<th colspan="2">1er trimestre</th>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Ejercicios 1</img></p></td>
				<td class="derechaAl"><a href="index.php?page=T1/indexT1">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Ejercicios 2</img></p></td>
				<td class="derechaAl"><a href="index.php?page=T2/indexT2">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Ejercicios Arrays</img></p></td>
				<td class="derechaAl"><a href="index.php?page=Arrays/indexArray">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Ejercicios Formularios</img></p></td>
				<td class="derechaAl"><a href="index.php?page=formularios/indexFormulario">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Ejercicios Funciones</img></p></td>
				<td class="derechaAl"><a href="index.php?page=Funciones/indexFunciones">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Ejercicios Cookies ...</img></p></td>
				<td class="derechaAl"><a href="index.php?page=cookies/indexCookies">IR</a></td>
			</tr>
		</table>
	</div>