	<div id=tablaUno align="center">		
		<table border="">
		<tr>
			<th colspan="2">Formularios</th>
		</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Calendario</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/formularios/vistaCalendario'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Suma</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/formularios/vistaSuma'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Suma 2</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/formularios/sumar'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Registro</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/formularios/vistaRegistro'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Verbos</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/formularios/verbos'; ?>">IR</a></td>
			</tr>
			<!--<tr>
				<td><p><img class="imgText" src="img/php.jpg">Proyecto verbos</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/formularios/pVerbos/index'; ?>">IR</a></td>
			</tr>-
			<tr>
				<td><p><img class="imgText" src="img/php.jpg"> </img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/formularios/paises/vistaPaises'; ?>"IR</a></td>
			</tr>-->
		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>