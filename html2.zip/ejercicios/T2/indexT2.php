
	<div id=tablaUno align="center">		
		<table border="">
			<th colspan="2">2 tema</th>
				<tr>
				
					<td><p><img class="imgText" src="img/imgTexto.jpg">Ejercicio 1</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T2/1'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Ejercicio 2</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T2/2'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Ejercicio 3</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T2/3'; ?>">IR</a></td>
				</tr>
				<!--<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Ejercicio 4</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T2/4'; ?>">IR</a></td>
				</tr>-->
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Ejercicio 5</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T2/5'; ?>">IR</a></td>
				</tr>
			</tr>
		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>
