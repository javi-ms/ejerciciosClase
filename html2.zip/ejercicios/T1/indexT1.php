
	<div id=tablaUno align="center">		
		<table border="">
			<th colspan="2">1er trimestre</th>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Errores del diseño web</img></p></td>
					<td class="derechaAl"><a href="https://elrincondejms.wordpress.com/2016/09/21/los-10-errores-del-diseno-grafico/">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgText" src="img/imgTexto.jpg">Resumen de la lectura desarrollo ágil</img></p></td>
					<td class="derechaAl"><a href="">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">info.php</img></p></td>
					<td class="derechaAl"><a href="info.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">Hola Mundo</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T1/holaMundo'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">Ficha personal</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T1/fichaPersonal'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">Area del circulo</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T1/circulo'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">1</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T1/1'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">2</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T1/2'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">3</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/T1/3'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">4</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/4.php'; ?>">IR</a></td>
				</tr>
				<tr>
					<td><p><img class="imgPHP" src="img/php.jpg">5</img></p></td>
					<td class="derechaAl"><a href="<?php echo 'index.php?page=/5.php'; ?>">IR</a></td>
				</tr>
		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>
