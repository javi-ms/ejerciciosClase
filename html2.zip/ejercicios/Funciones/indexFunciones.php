	<div id=tablaUno align="center">		
		<table border="">
			<tr>
				<th colspan="2">Funciones</th>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">DNI</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Funciones/DNI/index'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Nombre y apellido</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Funciones/NA/index'; ?>">IR</a></td>
			</tr>
			<!--
			<tr>
				<td><p><img class="imgText" src="img/imgTexto.jpg">Numero a Letras</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Funciones/numALetras/numALetras'; ?>">IR</a></td>
			</tr>
			-->
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Validar Contraseña</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Funciones/Pass/index'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Sumar</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Funciones/sumar/index'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Calcular tamaño del texto</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Funciones/texto/index'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Maquetar</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Funciones/maquetar/index'; ?>">IR</a></td>
			</tr>
		</table>
	</div>
	<p><a href="../../index.php">Atras</a></p>