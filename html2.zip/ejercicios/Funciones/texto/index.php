<!DOCTYPE html>
<html>
<head>
	<title>Calcular tamaño texto</title>
</head>
<body>
	<form method="post" action="?php echo 'index.php?page=/Funciones/texto/calcularTexto'; ?>">
		<label>Introduce texto</label>
		<br/>
		<textarea name="texto" rows="4" cols="50">Escribe un texto</textarea>
		<br/>
		<input type="submit" name="enviar" value="Calcular">
	</form>
</body>
</html>