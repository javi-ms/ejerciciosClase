<!DOCTYPE html>
<html>
<head>
	<title>Sumar recursivamente</title>
</head>
<body>
	<form method="post" action="?php echo 'index.php?page=/Funciones/sumar/sumar'; ?>">
		<label>Introduce Sumando</label>
		<input type="text" name="sumando">
		<input type="submit" name="enviar" value="Sumar">
	</form>
</body>
</html>