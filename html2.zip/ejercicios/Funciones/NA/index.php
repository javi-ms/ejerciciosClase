<!DOCTYPE html>
<html>
<head>
	<title>Averiguar letra DNI</title>
</head>
<body>
	<form method="post" action="<?php echo 'index.php?page=/Funciones/NA/calcularNA; ?>">
		<label>Introduce Nombre</label>
		<input type="text" name="nombre">
		<br/>
		<label>Introduce Apellido</label>
		<input type="text" name="apellido">
		<br/>
		<input type="submit" name="enviar" value="Calcular">
		
	</form>
</body>
</html>