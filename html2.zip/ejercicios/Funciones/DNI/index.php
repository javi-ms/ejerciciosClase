<!DOCTYPE html>
<html>
<head>
	<title>Averiguar letra DNI</title>
</head>
<body>
	<form method="post" action="<?php echo 'index.php?page=/Funciones/DNI/calcularDNI'; ?>">
		<label>Introduce DNI</label>
		<input type="text" name="numDNI">
		
		<input type="submit" name="espanol">
		<!--<input type="submit" name="extranjero">-->
		
	</form>
</body>
</html>