	<div id=tablaUno align="center">		
		<table border="">
			<tr>
				<th colspan="2">Arrays</th>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Calendario</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Arrays/vistaCalendario'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Curso</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Arrays/curso'; ?>">IR</a></td>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Flota</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Arrays/flota'; ?>">IR</a></td>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Meses</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Arrays/meses'; ?>">IR</a></td>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Verbos</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Arrays/verbos'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">Paises</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Arrays/paises/paises'; ?>">IR</a></td>
			</tr>

		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>
