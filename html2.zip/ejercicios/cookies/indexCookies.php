	<div id=tablaUno align="center">		
		<table border="">
			<tr>
				<th colspan="2">Cookies ...</th>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg">autentificacion</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Cookies/autentificacion/1'; ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg"></img>Contador</p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Cookies/contadorVisitas/contador'; ?>">IR</a></td>
			</tr>
		
			<tr>
				<td><p><img class="imgText" src="img/imgTexto.jpg">Curso</img></p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Cookies/curso/index'; ?>">IR</a></td>
			</tr>
			<!--
			<tr>
				<td><p><img class="imgText" src="img/php.jpg"></img>Curso</p></td>
				<td class="derechaAl"><a href="<?php /*echo 'index.php?page=/Cookies/curso/index';*/ ?>">IR</a></td>
			</tr>
			<tr>
				<td><p><img class="imgText" src="img/php.jpg"></img>Historial</p></td>
				<td class="derechaAl"><a href="<?php /*echo 'index.php?page=/Cookies/historial/historial';*/ ?>">IR</a></td>
			</tr>-->
			<tr>
				<td><p><img class="imgText" src="img/php.jpg"></img>Login</p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Cookies/login/index'; ?>">IR</a></td>
			</tr>
				<td><p><img class="imgText" src="img/php.jpg"></img>Agenda</p></td>
				<td class="derechaAl"><a href="<?php echo 'index.php?page=/Cookies/agenda/index'; ?>">IR</a></td>
		</table>
	</div>
	<p><a href="../../index.php">Atras</a></p>