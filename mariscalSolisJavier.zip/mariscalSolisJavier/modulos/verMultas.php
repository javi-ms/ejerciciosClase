<?php 

mostrarMultas();
/*
uasort($_SESSION['multas'], 'sort_by_orden');
function sort_by_orden ($a, $b) {
    return $_SESSION['multas']['fecha'] - $_SESSION['multas']['fecha'];
}*/
 ?>