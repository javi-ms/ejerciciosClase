<?php 
	require_once('modulos/funciones.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<LINK REL=StyleSheet HREF="style/style.css" TYPE="text/css" MEDIA=screen>
	<title>Ejercicios de PHP</title>
</head>
<body>
	
	<div id="tituloPHP"><h1>Registro de multas</h1></div>
	<a href="<?php echo 'index.php?page=/verMultas'; ?>">ver multas</a>
	
	<form action="" method="POST">
		<input type="submit" name="exit" name="Logaut">
	</form>
	<hr>
	