<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="formularioLogin.php">
	<label>Introduce tu nick</label>
		<input type="text" name="nameLogin">
		<br>
	<label>Introduce tu contraseña</label>	
		<input type="text" name="passLogin">
		<br/>
		<input type="submit" name="enviar" value="Login">

	</form>
</body>
</html>