<?php
	require_once "funciones.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Agenda de contactos</title>
	</head>
	<body>
		<h1 id="titulo">Agenda</h1>
		
		<table border="1" id="tablaCabecera">
			<tr>
				<td><a href="/ejercicios/cookies/agenda/">Principal</a></td>
				<td><a href="/ejercicios/cookies/agenda/modulos/anadirUser.php">Añadir</a></td>
			</tr>
		</table>
		<hr>
			<!--Informacion del usuario-->
			<!--el usuario "" esta dentro-->
<!--
cabecera
informacion
navegacion
acciones
contenido



agenda
alumnos
informacion: usted esta en el sistema como:
-->
