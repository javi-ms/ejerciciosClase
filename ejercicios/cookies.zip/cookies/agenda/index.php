<?php 
echo "<link rel='stylesheet' type='text/css' href='css/style.css'>";
require_once "modulos/header.php";
?>
<?php
require_once "modulos/body.php";
?>

<?php 
	require_once "modulos/footer.php";
?>