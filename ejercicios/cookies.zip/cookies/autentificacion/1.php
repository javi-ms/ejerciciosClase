<?php 
//Implementa un sistema de autentificación básico utilizando un formulario.
session_start();

if (!isset($_SESSION['auth'])) {
	$_SESSION['auth']==false
	echo "no existe";
}else{
	echo "string";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Autentificacion basica</title>
</head>
<body>
	<form>
		<input type="text" name="user">
		<input type="password" name="pass">
		<input type="submit" name="enviar">

	</form>
</body>
</html>