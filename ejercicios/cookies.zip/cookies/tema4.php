<!DOCTYPE html>
<html>
<head>
	<title>Ejercicios 1</title>
	<?php
	require_once "../modulos/header.php";
?>
</head>
<body>
	<div id=tablaUno align="center">		
		<table border="">
			<th colspan="2">1er trimestre</th>
				<tr>
					<td><p><img id="imgText" src="img/imgTexto.jpg">Errores del diseño web</img></p></td>
					<td id="derechaAl"><a href="https://elrincondejms.wordpress.com/2016/09/21/los-10-errores-del-diseno-grafico/">IR</a></td>
				</tr>
				<tr>
					<td><p><img id="imgText" src="img/imgTexto.jpg">Resumen de la lectura desarrollo ágil</img></p></td>
					<td id="derechaAl"><a href="">IR</a></td>
				</tr>
				<tr>
					<td><p><img id="imgPHP" src="img/php.jpg">info.php</img></p></td>
					<td id="derechaAl"><a href="info.php">IR</a></td>
				</tr>
				<tr>
					<td><p><img id="imgText" src="img/imgTexto.jpg">Ejercicio 1.2</img></p></td>
					<td id="derechaAl"><a href="ejercicios/eje1.1.pdf">IR</a></td>
				</tr>
				<tr>
					<td><p><img id="imgPHP" src="img/php.jpg">1.2</img></p></td>
					<td id="derechaAl"><a href="">IR</a></td>
				</tr>
				<tr>
					<td><p><img id="imgText" src="img/php.jpg">Hola Mundo</img></p></td>
					<td id="derechaAl"><a href="ejercicios/holaMundo.php">IR</a></td>
				</tr><tr>
					<td><p><img id="imgText" src="img/php.jpg">Ficha personal</img></p></td>
					<td id="derechaAl"><a href="ejercicios/fichaPersonal.php">IR</a></td>
				</tr><tr>
					<td><p><img id="imgText" src="img/php.jpg">Area del circulo</img></p></td>
					<td id="derechaAl"><a href="ejercicios/circulo.php">IR</a></td>
				</tr><tr>
					<td>a</td>
				<td id="derechaAl"><a href="">IR</a></td>
			</tr>
		</table>
	</div>
	
	<p><a href="../../index.php">Atras</a></p>
</body>
</html>
<?php
	//require_once "../../modulos/footer.php";
?>