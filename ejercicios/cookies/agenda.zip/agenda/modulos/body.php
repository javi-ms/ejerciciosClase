<?php
	
	//menu
	//añadir usuario
	//modificar usuario


?>
<!DOCTYPE html>
<html>
<head>
	<title>Agenda</title>
</head>
<body>
<!--Aqui deben de ir los usuarios que ya hayan-->
<?php
		mostrarAgendaIndex();
	  ?>
</body>
</html>