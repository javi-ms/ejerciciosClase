<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/estilos.css" media="screen" />
	<title>PRACTICA 5 
</title>
</head>
<body>
	<p id="titulos">Confeccione un programa que muestre una serie de mensajes en la pagina empleando el comando 
	ECHO. Tenga en cuenta que cuando utiliza el comando ECHO el mensaje se debe encerrar entre 
	comillas dobles. </p>
	<?php

	echo "¿Pregunta 1?";
	echo "<br/>";
	echo "hemos puesto una etiqueta br entre las dos para que haya un salto de linea";
	echo "<br/>";
	echo "Esta es la segunda prueba de echo";
	?>

</body>
</html>