<html> 
	<head> 
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="css/estilos.css" media="screen" />
	  <title>Hola Mundo</title> 
	</head> 
	<body> 
		<h1> El famoso script Hello World</h1> 
		<p> 
			<?php 
				echo "<b>Hola</b> Mundo!"; 
			?> 
		</p> 
		<ol>
			<li>¿Cuál es la diferencia con el ejercicio 2? </li>
				<p>La diferencia con el ejercicio 2 es que hemos colocado la etiqueta "b" dentro del echo para que se ponga en negrita la palabra Hola</p>
		</ol>
		
	</body> 
</html> 