<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="css/estilos.css" media="screen" />
		<title>PRACTICA8</title>
	</head>
	<body>
		<?php
		/*Definir tres variables enteras. Luego definir un string que incorpore dichas variables y las sustituya
		en tiempo de ejecucion. Recordar que una variable se sustituye cuando el string esta encerrado por 
		comillas dobles:
		$precio = 90;
		Echo “La computadora tiene un precio de $precio”; */

			$precio1 = 90;
			$precio2 = 5;
			$precio3 = 50;

			echo "la computadora tiene un precio de $precio2";

		?>
	</body>
</html>