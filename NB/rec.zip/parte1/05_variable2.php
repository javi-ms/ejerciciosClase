<html> 
	<head> 
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="css/estilos.css" media="screen" />
		<title></title> 
	</head> 
		<body> 
			<h1>Segundo ejemplo de Variables usando el operador concatenacion .</h1> 
			<p> 
				<?php 
				$Name = "Miguel"; 
				echo "Hola <b>" . $Name . "</b>, encantado de conocerte"; 
				?> 
			</p>
			<ol>
				<li>¿Qué es la concatenacion?</li>
					<p>La union de caracteres</p>
				<li>¿Cómo hacemos la concatenacion en php?</li>
					<p>Mediante un punto "."</p>
			</ol> 
	</body> 
</html> 