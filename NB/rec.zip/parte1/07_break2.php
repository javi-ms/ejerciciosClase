<html> 
	<head> 
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="css/estilos.css" media="screen" />
	  <title></title> 
	</head> 
	<body> 
		<h1>Break en la ventana del navegador con signo \ </h1> 
		<p> 
			<?php 
				$Name = "Miguel"; 
					echo "Hola <b>$Name</b>, encantado de conocerte<br>	\n"; 
					echo "Gracias por venir!\n"; 
			?> 
		</p> 
		<ol>
			<li>¿Cuál es la diferencia con el ejercicio 6? </li>
				<p>Aqui si te muestra los echos</p>
		</ol>
	</body> 
</html> 