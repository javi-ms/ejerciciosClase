<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../css/estilos.css" media="screen" />
	<title>Problema</title>
</head>
	<body>
		<form action="45_alumnos03.2.php" method="post">
			Ingrese el mail del alumno a consultar:
			<input type="text" name="mail">
			<br>
			<input type="submit" value="buscar">
		</form>
	</body>
</html>