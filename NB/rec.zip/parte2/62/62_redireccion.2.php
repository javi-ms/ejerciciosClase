<?php
header("Location: http://$_REQUEST[direccion]");
?>