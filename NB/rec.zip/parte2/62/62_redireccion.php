	<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../css/estilos.css" media="screen" />
	<title>Problema</title>
</head>
<body>
<form action="62_redireccion.2.php" method="post">
Ingrese dirección de sitio web (ej www.google.com):
<input type="text" name="direccion" size="30"><br>
<input type="submit" value="Redireccionar">
</form>
</body>
</html>