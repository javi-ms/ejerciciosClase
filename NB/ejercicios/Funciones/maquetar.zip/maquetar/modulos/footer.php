
		<div id="cajaTextGato">
			<img src="img/pataGato.png" id="pataGato">
			<div id="transRosa">
				<p class="cajaTexto">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					
				</p>
				<p class="cajaTexto">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					
				</p>
				<p class="cajaTexto">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				</p>
			</div>
		</div>
		<div id="trasNegra">
			<p class="cajaPie">Valid html5 / design and code by <a href="http://www.marijazaric.com/">marija zaric - creative simplicity</a></p>
			<p class="cajaPie">© 2011 cats template</p>
		</div>
	</body>
</html>