<?php
	$ipsValidas=array();
?>
